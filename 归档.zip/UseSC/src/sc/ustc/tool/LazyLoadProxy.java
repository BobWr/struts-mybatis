package sc.ustc.tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import net.sf.cglib.proxy.LazyLoader;
import sc.ustc.dao.Configuration;
import water.ustc.bean.Imformation;
import water.ustc.bean.UserBean;

public class LazyLoadProxy implements LazyLoader {

	private UserBean userBean;

	public Object loadObject() throws Exception {

		Map<String, String> jdbcMap = Configuration.jdbc_config();
		Class.forName(jdbcMap.get("driver"));
		Connection conn = DriverManager.getConnection(jdbcMap.get("url"), jdbcMap.get("userName"), jdbcMap.get("password"));

		String sqlString = "select * from useraccount where id = ?";
		PreparedStatement ps = conn.prepareStatement(sqlString);
		ps.setString(1, userBean.getId());

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			return rs.getObject(4, Imformation.class);
		}
		return null;

	}

	public LazyLoadProxy(UserBean userBean) {

		this.userBean = userBean;
	}
}
