package sc.ustc.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import sc.ustc.bean.OR_class;

public class Conversation {

	public static Object selectObj(Object o) {

		Class<?> cla = o.getClass();
		OR_class orC = Configuration.class_config(cla.getName());
		String table = orC.getTable();
		List<List<String>> propertyList = orC.getPropertyList();

		// �õ�object�����Լ�ֵ
		List<List<String>> fieldValueList = new ArrayList<List<String>>();
		for (int i = 0; i < propertyList.size(); i++) {

			try {
				Field field = cla.getDeclaredField(propertyList.get(i).get(0));
				field.setAccessible(true);
				String fieldString = (String) field.get(o);
				if (fieldString != null) {
					List<String> sList = new ArrayList<String>();
					sList.add(propertyList.get(i).get(1));
					sList.add(fieldString);
					fieldValueList.add(sList);
				}
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}

		// �����ѯsql
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("select ");
		for (int i = 0; i < fieldValueList.size(); i++) {
			if (fieldValueList.get(i).get(3).equals("false")) {
				sqlBuilder.append(fieldValueList.get(i).get(1) + ",");
			}
		}
		sqlBuilder.deleteCharAt(sqlBuilder.length() - 1);
		sqlBuilder.append(" from " + table + " where ");
		for (int i = 0; i < fieldValueList.size(); i++) {
			if (fieldValueList.get(i).get(3).equals("false")) {
				sqlBuilder.append(fieldValueList.get(i).get(0) + " = ? and ");
			}
		}
		sqlBuilder.delete(sqlBuilder.length() - 5, sqlBuilder.length() - 1);

		try {
			// ����DB
			Connection conn = getConnection();
			// select
			PreparedStatement ps = conn.prepareStatement(sqlBuilder.toString());
			for (int i = 0; i < fieldValueList.size(); i++) {
				ps.setString(i + 1, fieldValueList.get(i).get(1));
			}
			return ps.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static boolean deleteObjById(Object o) {

		try {

			// ͨ��������Ƶõ�object��id����
			Class<?> cla = o.getClass();
			Field id = cla.getDeclaredField("id");
			id.setAccessible(true);
			String idString = (String) id.get(o);

			// ����xml�ļ��õ���Ӧ�����ݿ��
			OR_class orC = Configuration.class_config(cla.getName());
			String table = orC.getTable();
			List<List<String>> propertyList = orC.getPropertyList();
			String tableId = null;
			for (int i = 0; i < propertyList.size(); i++) {
				if (propertyList.get(i).get(0).equals("id")) {
					tableId = propertyList.get(i).get(1);
				}
			}

			// ����DB
			Connection conn = getConnection();

			// delete
			String sql = "delete from " + table + " where " + tableId + " = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, idString);
			return ps.executeUpdate() == 1;

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return false;
	}

	private static Connection getConnection() throws ClassNotFoundException, SQLException {
		Map<String, String> jdbcMap = Configuration.jdbc_config();
		Class.forName(jdbcMap.get("driver"));
		Connection conn = DriverManager.getConnection(jdbcMap.get("url"), jdbcMap.get("userName"), jdbcMap.get("password"));
		return conn;
	}

	public static void main(String[] args) {

		OR_class orC = Configuration.class_config("water.ustc.bean.UserBean");
		System.out.println(orC.getPropertyList());
		System.out.println(Configuration.jdbc_config());

		// UserBean aaBean = new UserBean("100");
		//
		// Class<?> cla = aaBean.getClass();
		// System.out.println(UserBean.class);
		// System.out.println(cla.getName());
		//
		// try {
		// Field field = cla.getDeclaredField("userId");
		// field.setAccessible(true);
		// System.out.println(field.get(aaBean));
		// } catch (NoSuchFieldException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (SecurityException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IllegalArgumentException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IllegalAccessException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// System.out.println(Thread.currentThread().getContextClassLoader().getResource("or_mapping.xml").getPath());

	}
}
