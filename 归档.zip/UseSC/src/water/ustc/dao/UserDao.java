package water.ustc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import sc.ustc.dao.BaseDao;
import sc.ustc.dao.Conversation;

public class UserDao extends BaseDao {

	// public UserDao() {
	//
	// this.driver = "com.mysql.jdbc.Driver";
	// this.url = "jdbc:mysql://localhost:3306/user";
	// this.userName = "root";
	// this.password = "";
	//
	// this.driver = "org.sqlite.JDBC";
	// this.url = "jdbc:sqlite:H:\\SQLite\\databases\\user.db";
	// this.userName = null;
	// this.password = null;
	// }

	public boolean deleteObjById(Object o) {

		return Conversation.deleteObjById(o);
	}

	public Object selectObj(Object o) {

		return Conversation.selectObj(o);
	}

	@Override
	public boolean delete(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insert(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object query(String sql, String[] args) {

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = openDBConnection();
			ps = conn.prepareStatement(sql);
			for (int i = 0; i < args.length; i++) {
				ps.setString(i + 1, args[i]);
			}
			return ps.executeQuery();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeDBConnection(conn);
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}
}
