package water.ustc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LoginDao {

	String driver = "com.mysql.jdbc.Driver";
	String dbName = "user";
	String passWord = "";
	String userName = "root";
	String url = "jdbc:mysql://localhost:3306/" + dbName;

	public List<List<String>> select(String id, String password) {

		String sql = "select * from useraccount where name = ? and password = ?";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<List<String>> listlist = new ArrayList<List<String>>();
		List<String> list = new ArrayList<String>();
		try {
			// ��������
			Class.forName(driver);
			// �������
			conn = DriverManager.getConnection(url, userName, passWord);
			// ����prepareStatement
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, password);
			// ִ�в���
			rs = ps.executeQuery();
			while (rs.next()) {
				list.add(rs.getString(1));
				list.add(rs.getString(2));
				listlist.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listlist;
	}

	public void insert(String id, String password) {

		String sql = "insert into useraccount(name,password) values(?,?)";

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			// ��������
			Class.forName(driver);
			// �������
			conn = DriverManager.getConnection(url, userName, passWord);
			// ����prepareStatement
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, password);
			// ִ�в���
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
