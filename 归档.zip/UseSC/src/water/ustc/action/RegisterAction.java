package water.ustc.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sc.ustc.bean.ActionBean;
import water.ustc.dao.LoginDao;
import water.ustc.tools.Tools;

public class RegisterAction extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public String handleRegist(HttpServletRequest request, HttpServletResponse response, ActionBean actionbean) throws ServletException, IOException {

		String id = Tools.setUtf(request.getParameter("id"));
		String password = request.getParameter("password");
		LoginDao userDao = new LoginDao();
		HttpSession session = request.getSession();
		if (userDao.select(id, password) != null && !userDao.select(id, password).isEmpty()) {
			session.setAttribute("registMessage", "�û����Ѵ��ڣ�");
			return "failure";
		} else {
			userDao.insert(id, password);
			session.setAttribute("id", id);
			return "success";
		}
	}
}
