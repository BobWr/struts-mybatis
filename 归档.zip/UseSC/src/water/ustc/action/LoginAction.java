package water.ustc.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sc.ustc.bean.ActionBean;
import water.ustc.bean.UserBean;
import water.ustc.tools.Tools;

public class LoginAction extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public LoginAction() {
		super();
	}

	public String handleLogin(HttpServletRequest request, HttpServletResponse response, ActionBean actionBean) throws ServletException, IOException {

		String id = Tools.setUtf(request.getParameter("id"));
		String password = request.getParameter("password");

		UserBean userBean = new UserBean(id, password);
		HttpSession session = request.getSession();
		if (userBean.signIn()) {

			session.setAttribute("id", id);
			return "success";
		} else {
			session.setAttribute("loginMessage", "�û������������");
			return "failure";
		}

		// LoginDao userDao = new LoginDao();
		// HttpSession session = request.getSession();
		// if (userDao.select(id, password) != null && !userDao.select(id,
		// password).isEmpty()) {
		//
		// session.setAttribute("id", id);
		// return "success";
		// } else {
		// session.setAttribute("loginMessage", "�û������������");
		// return "failure";
		// }
	}
}
