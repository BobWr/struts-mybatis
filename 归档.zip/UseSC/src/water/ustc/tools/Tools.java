package water.ustc.tools;

import java.io.UnsupportedEncodingException;

public class Tools {

	public static String setUtf(String str) throws UnsupportedEncodingException {

		if (str != null) {
			return new String(str.getBytes("ISO-8859-1"), "utf-8");
		}
		return null;
	}
}
