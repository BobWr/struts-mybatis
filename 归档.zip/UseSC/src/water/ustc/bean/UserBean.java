package water.ustc.bean;

import java.sql.ResultSet;

import net.sf.cglib.proxy.Enhancer;
import sc.ustc.tool.LazyLoadProxy;
import water.ustc.dao.UserDao;

public class UserBean {

	private String id;
	private String userName;
	private String userPass;
	private Imformation imfor;

	public UserBean(String id) {
		this.id = id;
		this.imfor = inforProxy();
	}

	@SuppressWarnings("static-access")
	Imformation inforProxy() {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(Imformation.class);
		return (Imformation) enhancer.create(Imformation.class, new LazyLoadProxy(this));
	}

	public UserBean(String userName, String userPass) {
		this.userName = userName;
		this.userPass = userPass;
	}

	public boolean signIn() {

		UserDao userDao = new UserDao();

		ResultSet rs = (ResultSet) userDao.selectObj(this);
		if (rs != null) {
			return true;
		}
		return false;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
}
