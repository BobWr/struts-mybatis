package water.ustc.interceptor;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import sc.ustc.bean.ActionBean;

public class LogInterceptor {

	private static final long serialVersionUID = -5129695450017263662L;

	private static String name;
	private static String s_time;
	private String e_time;
	private String result;

	public void preAction(HttpServletRequest request, HttpServletResponse response, ActionBean actionBean) {

		// ��ȡ����ʱ�䣬�����action name
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		setS_time(df.format(new Date()));
		setName(actionBean.getActionName());
	}

	public void afterAction(HttpServletRequest request, HttpServletResponse response, ActionBean actionBean, String results) {

		// ��ȡ����ʱ�䣬�����result
		setResult(results);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		setE_time(df.format(new Date()));
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder buillder = dbf.newDocumentBuilder();
			File file = new File("F:/log.xml");
			if (!file.exists() && file.createNewFile()) {
				// file�����ڣ��½��ļ�
				Document doc = buillder.newDocument();
				doc.setXmlStandalone(true);
				Element root_log = doc.createElement("log");
				Element action = doc.createElement("action");
				Element name = doc.createElement("name"), sTime = doc.createElement("s-time"), etime = doc.createElement("e-time"), aresult = doc
						.createElement("result");
				name.setTextContent(getName());
				sTime.setTextContent(getS_time());
				etime.setTextContent(getE_time());
				aresult.setTextContent(getResult());
				action.appendChild(name);
				action.appendChild(sTime);
				action.appendChild(etime);
				action.appendChild(aresult);
				root_log.appendChild(action);
				doc.appendChild(root_log);
				TransformerFactory tff = TransformerFactory.newInstance();
				Transformer tf = tff.newTransformer();
				tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				tf.transform(new DOMSource(doc), new StreamResult(file));
			} else if (file.exists()) {
				// file���ڣ�����ڵ�
				Document doc = buillder.parse(file);
				doc.setXmlStandalone(true);
				Element root_log = doc.getDocumentElement();
				Element action = doc.createElement("action");
				Element name = doc.createElement("name"), sTime = doc.createElement("s-time"), etime = doc.createElement("e-time"), aresult = doc
						.createElement("result");
				name.setTextContent(getName());
				sTime.setTextContent(getS_time());
				etime.setTextContent(getE_time());
				aresult.setTextContent(getResult());
				action.appendChild(name);
				action.appendChild(sTime);
				action.appendChild(etime);
				action.appendChild(aresult);
				root_log.appendChild(action);
				TransformerFactory tff = TransformerFactory.newInstance();
				Transformer tf = tff.newTransformer();
				tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				tf.transform(new DOMSource(doc), new StreamResult(file));
			}

		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		LogInterceptor.name = name;
	}

	public String getS_time() {
		return s_time;
	}

	public void setS_time(String sTime) {
		s_time = sTime;
	}

	public String getE_time() {
		return e_time;
	}

	public void setE_time(String eTime) {
		e_time = eTime;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
}
