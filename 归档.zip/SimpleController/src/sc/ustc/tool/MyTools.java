package sc.ustc.tool;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import sc.ustc.bean.ActionBean;

public class MyTools {

	public ActionBean readXml_dom(String actionName, String path) {

		try {
			// controller.xml������DOM��
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder buillder = dbf.newDocumentBuilder();
			Document doc = buillder.parse(new File(path));
			// ����interceptor�ڵ�
			NodeList interceptorsLi = doc.getElementsByTagName("interceptor");
			Map<String, List<String>> InterceptorMap = new HashMap<String, List<String>>();
			for (int i = 0; i < interceptorsLi.getLength(); i++) {
				List<String> interDirts = new ArrayList<String>();
				Element interceptor = (Element) interceptorsLi.item(i);
				interDirts.add(interceptor.getAttribute("name"));
				interDirts.add(interceptor.getAttribute("class"));
				interDirts.add(interceptor.getAttribute("predo"));
				interDirts.add(interceptor.getAttribute("afterdo"));
				InterceptorMap.put(interceptor.getAttribute("name"), interDirts);
			}
			// ����action�ڵ�
			NodeList actions = doc.getElementsByTagName("action");
			for (int i = 0; i < actions.getLength(); i++) {
				Element action = (Element) actions.item(i);
				if (action.getAttribute("name").equals(actionName)) {
					// ��ȡresult�ڵ�
					Map<String, List<String>> actionResultMap = new HashMap<String, List<String>>();
					NodeList results = action.getElementsByTagName("result");
					for (int j = 0; j < results.getLength(); j++) {
						Element childNode = (Element) results.item(j);
						List<String> resultList = new ArrayList<String>();
						resultList.add(childNode.getAttribute("name"));
						resultList.add(childNode.getAttribute("type"));
						resultList.add(childNode.getAttribute("value"));
						actionResultMap.put("result" + childNode.getAttribute("name"), resultList);

					}
					// ��ȡinterceptor�ڵ�
					Map<String, List<String>> actionInterceptors = new HashMap<String, List<String>>();
					NodeList interceptors = action.getElementsByTagName("interceptro-ref");
					for (int j = 0; j < interceptors.getLength(); j++) {
						Element childNode = (Element) interceptors.item(j);
						actionInterceptors.put(String.valueOf(j), InterceptorMap.get(childNode.getAttribute("name")));
					}
					return new ActionBean(actionName, action.getAttribute("class"), action.getAttribute("method"), actionResultMap, actionInterceptors);
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	// public Map<String, String> readXml(String actionName, String path) throws
	// FileNotFoundException {
	//
	// File fd = new File(path);
	// BufferedReader br = new BufferedReader(new FileReader(fd));
	// StringBuilder sb = new StringBuilder();
	// String line = null;
	//
	// try {
	// while ((line = br.readLine()) != null) {
	// sb.append(line);
	// }
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	//
	// String[] sl = sb.toString().split("</action>");
	// Map<String, String> map = new HashMap<String, String>();
	// for (int i = 0; i < sl.length; i++) {
	// String acName = sl[i].substring(sl[i].indexOf("name=\"") + 6);
	//
	// if (acName.startsWith(actionName + "\"")) {
	// map.put("action", actionName);
	// String classN = acName.substring(acName.indexOf("class=\"") + 7);
	// map.put("class", classN.substring(0, classN.indexOf("\"")));
	// String methodN = classN.substring(classN.indexOf("method=\"") + 8);
	// map.put("method", methodN.substring(0, methodN.indexOf("\"")));
	//
	// String[] result = methodN.split("<result");
	// for (int j = 1; j < result.length; j++) {
	// String resN = result[j].substring(result[j].indexOf("name=\"") + 6);
	// String resT = resN.substring(resN.indexOf("type=\"") + 6);
	// String resV = resT.substring(resT.indexOf("value=\"") + 7);
	// String res = resT.substring(0, resT.indexOf("\"")) + "-" +
	// resV.substring(0, resV.indexOf("\""));
	// map.put("result" + resN.substring(0, resN.indexOf("\"")), res);
	// }
	// }
	//
	// }
	//
	// return map;
	// }
}
